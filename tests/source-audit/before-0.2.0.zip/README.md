---
type: product_handoff
layer: output
status: active
validity: current
retrieval: on_demand
effective_from: '2026-10-06'
updated: '2026-10-06'
last_reviewed: '2026-10-06'
confidence: confirmed
privacy: private
schema_version: temporal-governance-v2
---

# 低成本生活指南 · 微信小程序

这是本项目唯一接手入口。当前 0.2.0 是原生微信小程序，提供 8 个生活主题、34 章、667 条建议的离线阅读、原文全文检索、筛选、逐条收藏、最近阅读和来源查看。

0.2.0 按用户要求参考「生意有谱」的实际界面重新制作视觉：暖白底、深色正文、橙色操作、细沙色边框，首页八主题改为两行图标导航，列表、阅读、搜索和收藏页同步调整。参考仅用于视觉标准，未复制该项目的品牌形象、数据或业务功能。内容与收藏存储格式保持一致；视觉反馈仍待用户本人确认。

工程入口：`miniprogram/project.config.json`。使用微信开发者工具导入 `miniprogram`，或者运行同目录 `打开微信开发版.ps1`。当前使用官方测试身份 `touristappid`，不使用参考作者或学员手记的 AppID。

## 当前交付与验证

- 完整内容构建与逐项核对：`release/content-build-report.json`。
- 独立测试：`tests/independent-qa.json`，使用隔离环境检查内容、筛选、搜索、记录保护和返回路径。
- 官方模拟器操作与截图：`tests/official/result.json`、`tests/official/*.png`。以实际回执为准，不能把隔离测试写成手机验收。
- 本轮六个页面与两处滚动截图：`tests/visual-refresh/`；旧版对照截图：`tests/visual-before/`。
- 原生工程包与校验值：`release/delivery-manifest.json`。

本轮没有确认生活指南自己的真实 AppID。其他可访问聊天中未检出能归属本项目的身份，不等于用户从未提供。确认 AppID 后再生成手机开发预览码；此版尚未正式上传、送审或发布。

## 怎样使用

1. 在“指南”按生活主题进入，或搜索一个具体问题。
2. “全部”可组合主题、章节、不花钱和作者证据分级筛选。
3. 打开建议先看适用条件，再看成本、收益与出处；正文可选择复制。
4. 点击“收藏这条建议”，以后在“收藏”中查找。最近 100 条阅读记录也保存在这里，可单独清空。
5. 在详情展开“原始出处”，复制链接到浏览器查看；本版不承诺在微信内直接打开任意外部网站。

收藏与阅读记录仅保存在当前设备。没有自建账号、后台、支付、云同步或外部 AI 请求。清理缓存、删除小程序或换设备可能丢失记录。格式损坏时保留原数据，不自动覆盖或重置。

## 内容来源与版本

正文来自 [eternity4719/HowToLiveBetter](https://github.com/eternity4719/HowToLiveBetter)，固定版本 `20718eeab32cb8506971fb71b03e66a91077be07`，2026-10-06 获取。34 章中的编号建议全部入库，保留六类正文信息及章节附记；争议分级与原文限制不删除。本轮校验的是转换完整性，没有逐条重新验证医学、法律或金融结论。

阅读与收藏结构参考 [HuiTurn/HowToLiveBetter](https://github.com/HuiTurn/HowToLiveBetter)，固定版本 `717135e7527025a55f283f2fba98a42a7eeca224`。本版重新制作微信页面、逐条索引和主题导航，未使用参考作者的图片、品牌身份或 AppID。内容使用 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)，许可全文在 `licenses/CC-BY-4.0.txt`；署名、来源、修改说明也保留在小程序“关于”页面。

上游原始 ZIP 与校验说明保存在 [[10_Sources/原始材料/低成本生活指南小程序-2026-10-06/README]]。开发包不携带私人知识库资料或其他小程序身份。

## 维护与验收

内容构建器：`python scripts/build-content.py --source-root <固定版本的上游解压目录>`。每次更新必须检查构建报告、来源链接、争议文字、主包及内容分包体积；原作者条目编号可能变化，不应只按新编号覆盖旧收藏。

独立测试：`npm test`。微信测试使用 `miniprogram-automator@0.12.1`，先在官方工具开启项目自动化，再设置 `WX_AUTOMATION_ENDPOINT` 运行 `npm run test:wechat`。此依赖只用于开发，不进小程序代码包。

首版最小验证是“能找到一条建议、读懂条件、保存并重新找到”。本次不自动启动收费、内容营销或运营排期，既有星图经营主线不变。
