const {catalog}=require('../../lib/catalog');
Page({data:{meta:Object.assign({},catalog.meta,{version:require('../../lib/version')})},copy(e){const url=e.currentTarget.dataset.url;if(!/^https?:\/\//.test(url||''))return;wx.setClipboardData({data:url,success(){wx.showToast({title:'链接已复制',icon:'none'});}});}});
